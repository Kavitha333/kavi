class Diwali
	{
	public static void main(String[] aa)
	{
	pooja();
	burningCrackers();
	makingSweetsAtHome();	


	}
	
	static void pooja()
	{
	System.out.println("Pooja @ 6");
	}
	
	 static void burningCrackers()
	{
	System.out.println("Happy Diwali");
	}
	
	static void makingSweetsAtHome()
	{
	System.out.println("Making Golab jamun");
	}
	
}