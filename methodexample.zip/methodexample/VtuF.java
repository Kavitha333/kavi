class FrustratedStudent
{
	public static void main(String a[])
	{
	Vtu.moneyMaker();
	Vtu.Worst();
	}
}