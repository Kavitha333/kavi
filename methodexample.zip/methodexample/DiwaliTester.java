class DiwaliTester
	{
	public static void main(String[] aa)
	{
	Diwali.pooja();
	Diwali.burningCrackers();
	Diwali.makingSweetsAtHome();
	}
}