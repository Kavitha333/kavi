class Vtu
{
 	 static void moneyMaker()
 	{
		System.out.println("Money minded");
	}

	static void Worst()	
	{
		System.out.println("This site can't be reached");
	}
}	