class Kgf
	{
		public static void main(String a[])
		{
			System.out.print("Movie");
		}
	}