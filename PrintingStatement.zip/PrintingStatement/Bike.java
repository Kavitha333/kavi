class RoyalEnfield
 	{
		public static void main(String a[])
		{
			System.out.print("Favorite bike");
		}
	} 