class ConvertPriToNonPri
{
	public static void main(String dd[])
	{
		Integer myInt=456;
		Long myLong=420420420l;
		Character myChar='c';

                System.out.println(myInt);
                System.out.println(myLong);
	       System.out.println(myChar);

	

	}
}