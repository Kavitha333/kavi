class ConvertPriToNonPri
{
	public static void main(String dd[])
	{
		Integer myInt=456;
		Long myLong=42042042042;
		Character myChar='c';

                System.out.println(myInt);
                System.out.println(myLong);
	       System.out.println(myChar);

	

	}
}