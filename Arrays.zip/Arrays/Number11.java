class Number
{
	public static void main(String a[])
	{
		int age=20;
		int AGE=30;
		int AgE=87;
		System.out.println(age);
		System.out.println(AGE);
		System.out.println(AgE);
	}
}