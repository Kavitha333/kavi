class UserInfo 
{
 	public static void main(String ss[])
		{
		for(int info=0; info<=ss.length-1;info++)
			{
			long userInfo=Long.parseLong(ss[info]);
			System.out.println(userInfo);
			}
		}	
}