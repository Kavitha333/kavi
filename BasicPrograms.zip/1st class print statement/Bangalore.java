class Rcb
{
   public static void main(String a[])
       {
         System.out.print("e sala cup namde");
	}
}