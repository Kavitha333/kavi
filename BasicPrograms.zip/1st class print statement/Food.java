class Food
	{
	public static void main(String a[])
		{
                    System.out.print("Needed for everyone");
		}
	}
		